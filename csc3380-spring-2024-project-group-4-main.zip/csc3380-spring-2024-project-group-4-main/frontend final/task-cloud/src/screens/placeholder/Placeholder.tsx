import React from 'react'

const Placeholder = () => {
  return (
    <div>Placeholder</div>
  )
}

export default Placeholder